const CACHE_NAME = "earnpkr-shell-v1";
const SHELL_FILES = [
  "./index.html",
  "./app.html",
  "./admin.html",
  "./auth.html",
  "./shared.js",
  "./parallax.js",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

/* Network-first for API/data calls (Supabase, Cloudinary) so data is always fresh.
   Cache-first for the static app shell so it loads instantly and works offline. */
self.addEventListener("fetch", (event) => {
  const url = event.request.url;
  const isRemoteData = url.includes("supabase.co") || url.includes("cloudinary.com");

  if (isRemoteData) {
    event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      return (
        cached ||
        fetch(event.request)
          .then((response) => {
            if (event.request.method === "GET" && response && response.status === 200) {
              const clone = response.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
            }
            return response;
          })
          .catch(() => cached)
      );
    })
  );
});
